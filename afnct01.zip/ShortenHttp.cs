using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace afnct01
{
    public static class ShortenHttp
    {
        [FunctionName("ShortenHttp")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            name = name ?? data?.name;

            string responseMessage = string.IsNullOrEmpty(name)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, {name}. This HTTP triggered function executed successfully.";

            return new OkObjectResult(responseMessage);
        }

        [FunctionName("GetTodos")]
        public static async Task<IActionResult> GetTodos(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)]
            HttpRequest req, ILogger log)
        {
            log.LogInformation("Getting todo list items");
            var todos = await new ShortenContext().UrlMappings.ToListAsync();
            return new OkObjectResult(todos);
        }
    }

    public class UrlMapping
    {
        /// <summary>
        /// Identificador del mapeo de url
        /// </summary>
        /// <value>Entero</value>
        public int Id { get; set; }
        /// <summary>
        /// Valor original de la url
        /// </summary>
        /// <value>Cadena</value>
        public string OriginalUrl { get; set; } = string.Empty;
        /// <summary>
        /// Valor corto de la url
        /// </summary>
        /// <value>Cadena</value>
        public string ShortenedUrl { get; set; } = string.Empty;
    }

    public class ShortenContext : DbContext
    {
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        //static string conexion = new ConfigurationBuilder().AddEnvironmentVariables().AddJsonFile("local.settings.json").Build().GetConnectionString("ShortenDB");
        static string conexion = new ConfigurationBuilder().AddEnvironmentVariables().Build().GetConnectionString("ShortenDB");
        public ShortenContext() : base(SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder(), conexion, o => o.CommandTimeout(300)).Options)
        {
        }
        /// <summary>
        /// Propiedad que representa la tabla de mapeo de urls
        /// </summary>
        /// <value>Conjunto de UrlMapping</value>
        public DbSet<UrlMapping> UrlMappings { get; set; }
    }
}
